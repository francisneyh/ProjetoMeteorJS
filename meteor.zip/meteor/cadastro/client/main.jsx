import { Template } from 'meteor/templating';
import { Meteor } from 'meteor/meteor';

import './main.html';
import './body.html';

Template.cadastro.helpers({
  emails = function(){
    return Emails.find();
  }
});

Template.cadastro.events({
  'submit form' : function(e, template){
    e.preventDefault();
    var email = template.find('[data-email').value;
    Emails.insert({ valor : email }), function(error, id) { 
        if (error) {
          console.error(error);
        }
        console.log(id);
    });
  },
  'click #excluir' : function (e) {
      Emails.remove(this.id);
  }  
});